package ab04a1;

public class TraceOperator implements Operator {
	
	public Object execute(Matrix2D m1) {
		
		return m1.a+m1.d;							// Spur 2x2-Matrix der Form:
											// a b
	}										// c d

}
