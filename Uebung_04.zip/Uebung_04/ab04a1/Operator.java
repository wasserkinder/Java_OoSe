package ab04a1;

public interface Operator {

	public Object execute(Matrix2D m1);	// c) Methode execute m. Rueckgabewert Object und Argument m1

}
