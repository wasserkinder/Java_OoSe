package ab04a3;

public interface Food {
	public String getMeal();
}


