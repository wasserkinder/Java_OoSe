package ab04a3;

public class Cauliflower implements Food{
	public String getMeal() {
		return "Blumenkohl an Gorgonzolasoße";
		}
}
