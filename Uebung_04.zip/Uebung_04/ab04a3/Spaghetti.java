package ab04a3;

public class Spaghetti implements Food {
	public String getMeal() {
		return "Spaghetti Bologneser Art";
		}
}
