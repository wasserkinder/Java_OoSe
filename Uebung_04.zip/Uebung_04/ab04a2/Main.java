// YK: ab04a2 weicht nur in korrigierter Klein-/Großschreibung von "Point" von Milad N.s Datei ab
package ab04a2;

public class Main {

	public static void main(String[] args) {

		Point p1 = new Point(1,2);
		Point p2 = new Point(3,4);
		System.out.println(p1.string());
		System.out.println(p2.string());
		System.out.println(p1.distance(p1,p2));
		Point p3 = new Point3D(1,2,5);
		Point p4 = new Point3D(3,4,5);
		System.out.println(p3.string());
		System.out.println(p4.string());
		System.out.println(p3.distance(p3,p4));
	}

}

