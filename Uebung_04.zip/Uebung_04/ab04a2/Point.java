// YK: ab04a2 weicht nur in korrigierter Klein-/Großschreibung von "Point" von Milad N.s Datei ab
package ab04a2;

public class Point {
	double x, y;
	public Point(double x, double y){
		this.x = x;
		this.y = y;
	}
	
	public double distance(Point p1, Point p2){
		double x = p1.x - p2.x;
		double y = p1.y - p2.y;
		return Math.sqrt((Math.pow(x, 2) + Math.pow(y, 2)));
	}
	public Point getPoint(){
		return this;
	}
	public double getx(){
		return this.x;
	}
	public double gety(){
		return this.y;
	}
	public String x_koordinate(){
		return String.valueOf(x);
	}
	public String y_koordinate(){
		return String.valueOf(y);
	}
	public String string(){
		return String.format("X: " + x_koordinate() + "\nY: " + y_koordinate());
	}
}

